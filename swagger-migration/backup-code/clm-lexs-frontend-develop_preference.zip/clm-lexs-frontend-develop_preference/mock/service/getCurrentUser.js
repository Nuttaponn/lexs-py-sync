module.exports = {
    getCurrentUser: require('../data/userManagement/getCurrentUser.json'),
  };