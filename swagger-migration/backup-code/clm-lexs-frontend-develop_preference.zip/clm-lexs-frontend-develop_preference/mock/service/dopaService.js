

module.exports = {
    queryDopaTask: require('../data/dopa/queryDopaTask.json'),
    queryAgentResponse:require('../data/dopa/queryAgentResponse.json')
  };