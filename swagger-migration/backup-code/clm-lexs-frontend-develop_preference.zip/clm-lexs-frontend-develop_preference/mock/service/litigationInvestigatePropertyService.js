
module.exports = {
  litigationCases: require('../data/InvestigationAsset/litigation-cases.json'),
  litigationCreateInfo: require('../data/InvestigationAsset/create-info.json'),
  investigationInfo: require('../data/InvestigationAsset/investigation-info.json'),
};

