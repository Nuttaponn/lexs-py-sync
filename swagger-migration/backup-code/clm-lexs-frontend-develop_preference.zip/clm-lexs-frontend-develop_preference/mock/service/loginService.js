
module.exports = {
  generateToken: require('../data/login/generateToken.js'),
  ldapFailed: require('../data/login/ldapFailed.json'),
  authenFailed: require('../data/login/authenFailed.json'),
};

